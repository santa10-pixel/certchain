'use client';
import { createContext, useContext, useState, useEffect } from 'react';

export type Role = 'HOME' | 'UNIVERSITY' | 'STUDENT' | 'VERIFIER' | 'ADMIN';

interface RoleContextType {
  role: Role;
  setRole: (role: Role) => void;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: React.ReactNode }) {
  const [role, setRoleState] = useState<Role>('HOME');

  useEffect(() => {
    const saved = localStorage.getItem('certix_role') as Role;
    if (saved) setRoleState(saved);
  }, []);

  const setRole = (newRole: Role) => {
    setRoleState(newRole);
    localStorage.setItem('certix_role', newRole);
  };

  return (
    <RoleContext.Provider value={{ role, setRole }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (context === undefined) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
}
